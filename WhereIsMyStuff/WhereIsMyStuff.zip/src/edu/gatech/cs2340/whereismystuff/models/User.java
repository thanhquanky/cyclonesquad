package edu.gatech.cs2340.whereismystuff.models;
//import java.lang.String;

public class User 
{
	public String username;
	private String password;
	//private ArrayList<Item> ownedItems;
	private boolean isUnlocked=true;
	private int loginAttempts=0;
	
	public User(String username, String password)
	{
		this.username=username;
		this.password=password;
	}
	
	public boolean verify(String password)
	{
		if(password.equals(this.password) && isUnlocked)
			return true;
		else
			loginAttempts++;
		return true;
	}
}
