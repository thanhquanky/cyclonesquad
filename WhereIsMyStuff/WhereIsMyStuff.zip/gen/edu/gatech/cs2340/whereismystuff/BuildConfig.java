/** Automatically generated file. DO NOT MODIFY */
package edu.gatech.cs2340.whereismystuff;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}